/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Paquete;

/**
 *
 * @author daw121
 */
public class Principal {

    public static void main(String[] args) {
        cuatro c1 = new cuatro();
    int[][] tabla = new int[6][7]; 


//        c1.tabla2();
        c1.mostrarTabla();
        System.out.println(tabla.length + " filas, " + tabla[0].length + " columnas");
        
        
    }
    
    
}
